/**
 * Mostra els números parells de l'1 al 200
 * @author eina
 */

public class Ex02 {
	public static void main(String[] args) {
		for (int i = 2; i <= 200; i+=2) {
			System.out.println(i);
		}
	}
}
