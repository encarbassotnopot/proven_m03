/**
 * Diu "Bon dia" a l'usuari
 * @author eina
 */

public class Ex01 {
	public static void main(String[] args) {
		System.out.println("Bon dia");
	}
}
